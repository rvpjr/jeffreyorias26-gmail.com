
<template>
  <div class="text-center">
  <button type="button" class="py-4 px-5 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" data-hs-overlay="#hs-bg-gray-on-hover-cards">
    APPLY NOW!
  </button>
</div>
<div id="hs-bg-gray-on-hover-cards" class="hs-overlay hidden size-full fixed top-0 start-0 z-[80] overflow-x-hidden overflow-y-auto pointer-events-none">
    <div class="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-4xl sm:w-full m-3 sm:mx-auto h-[calc(100%-3.5rem)]">
      <div class="max-h-full overflow-hidden flex flex-col bg-white border shadow-sm rounded-xl pointer-events-auto dark:bg-gray-800 dark:border-gray-700 dark:shadow-slate-700/[.7]">
        <div class="flex justify-between items-center py-3 px-4 border-b dark:border-gray-700">
          <h3 class="font-bold text-gray-800 dark:text-gray-200">
            LOAN APPLICATION FORM
          </h3>
          <button type="button" class="flex justify-center items-center size-7 text-sm font-semibold rounded-lg border border-transparent text-gray-800 hover:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:border-transparent dark:hover:bg-gray-700 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" data-hs-overlay="#hs-bg-gray-on-hover-cards">
            <span class="sr-only">Close</span>
            <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
          </button>
        </div> <!-- close div -->
        <div class="p-4 overflow-y-auto">
          <div class="sm:divide-y divide-gray-200 dark:divide-gray-700">
            <div class="py-2 sm:py-4"> <p>DATE_____</p></div>
            <div class="py-3 sm:py-6">
              <h6 class="mb-2 text-xs font-semibold uppercase text-gray-600 dark:text-gray-400">
                To apply, submit completely filled-out load application form & documentary requirements.
              </h6>
              <div class="sm:col-span-3">
              <label for="af-account-source-checkbox" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
              SOURCE
              </label>
              <div class="sm:col-span-3">
                  <div class="sm:flex">
                      <label for="af-account-source-checkbox-walkin" class="flex py-2 px-3 w-full border border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600">
                        <input type="radio" name="af-account-source-checkbox" class="shrink-0 mt-0.5 border-gray-300 rounded-full text-blue-600 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-800 dark:border-neutral-500 dark:checked:bg-blue-500 dark:checked:border-blue-500 dark:focus:ring-offset-gray-800" id="af-account-source-checkbox-walkin">
                        <span class="text-sm text-gray-500 ms-3 dark:text-gray-400">Walk in</span>
                      </label>

                      <label for="af-account-source-checkbox-loadspecialist" class="flex py-2 px-3 w-full border border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600">
                        <input type="radio" name="af-account-source-checkbox" class="shrink-0 mt-0.5 border-gray-300 rounded-full text-blue-600 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-800 dark:border-neutral-500 dark:checked:bg-blue-500 dark:checked:border-blue-500 dark:focus:ring-offset-gray-800" id="af-account-source-checkbox-loanspecialist">
                        <span class="text-sm text-gray-500 ms-3 dark:text-gray-400">Loan Specialist</span>
                      </label>

                      <label for="af-account-source-checkbox-telemarkerter" class="flex py-2 px-3 w-full border border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600">
                        <input type="radio" name="af-account-source-checkbox" class="shrink-0 mt-0.5 border-gray-300 rounded-full text-blue-600 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-800 dark:border-neutral-500 dark:checked:bg-blue-500 dark:checked:border-blue-500 dark:focus:ring-offset-gray-800" id="af-account-source-checkbox-telemarketer">
                        <span class="text-sm text-gray-500 ms-3 dark:text-gray-400">Telemarketer</span>
                      </label>
                    </div>
                </div>
            </div>
          </div>

  <div class="max-w-4xl px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto">
    <div class="bg-white rounded-xl shadow p-4 sm:p-7 dark:bg-slate-900">
      <div class="mb-8">
        <h2 class="text-xl font-bold text-gray-800 dark:text-gray-200">
          BORROWER'S PERSONAL INFORMATION (MANDATORY)
        </h2>
        <p class="text-sm text-gray-600 dark:text-gray-400">
          TO APPLY, SUBMIT COMPLETELY FILLED-OUT LOAD APPLICATION FORM & DOCUMENTARY REQUIREMENTS.
        </p>
      </div>
       
    </div>
  </div>
      </div>
      <div class="max-w-full mx-auto">
    <div class="bg-white shadow-md rounded-lg">
      <!-- Stepper -->
      <div class="flex justify-between items-center px-8 py-4 border-b">
        <div v-for="(step, index) in steps" :key="index" class="text-gray-600">
          <span :class="{ 'font-bold': currentStep === index }">{{ index + 1 }}</span>
          <span v-if="index < steps.length - 1" class="mx-2">-</span>
        </div>
      </div>
      
      <!-- Form Content -->
      <div class="p-8">
        <div v-if="currentStep === 0">
          <!-- Step 1: Form fields -->
          <PersonalInformation v-model:personalInformation="loan.personal_information" v-model:validator="validator "></PersonalInformation>
          <IncomeInformation v-model:incomeInformation="loan.employer_information" v-model:validator="validator"></IncomeInformation>
          <BankAccounts v-model:bankAccounts="loan.releasings" v-model:validator="validator"></BankAccounts>
          <!-- Other fields for step 1 -->
        </div>
        <div v-else-if="currentStep === 1">
          <CoBorrowerInformation v-model:coborrowerInformation="loan.coborrowers" v-model:validator="step2Validator"></CoBorrowerInformation>
          <!-- Step 2: Form fields -->
          TEST
          <!-- Other fields for step 2 -->
        </div>
        <!-- Add more steps as needed -->
        <!-- <div v-else-if="currentStep === 2">
          ss 
          Step 2: Form fields 
          TEST
          Other fields for step 2
        </div> -->
      </div>

      <!-- Buttons -->
      <div class="flex justify-between items-center px-8 py-4">
        <button @click="prevStep" :disabled="currentStep === 0" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md">Previous</button>
        <button @click="nextStep" :disabled="currentStep === steps.length - 1" class="px-4 py-2 bg-blue-500 text-white rounded-md">Next</button>
         

      </div>
    </div>
  </div>

        <div class="flex justify-end items-center gap-x-2 py-3 px-4 border-t dark:border-gray-700">
          <p class="inline-flex items-center gap-x-1 text-sm text-blue-600 decoration-2 hover:underline font-medium dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="../docs/index.html">
            button here
            <svg class="flex-shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
          </p>
        </div>
      </div>
    </div>
  </div>
  </div>
  </template>

  <script setup>

  import { ref } from "vue";
  import VueTailwindDatepicker from "vue-tailwind-datepicker";
  import PersonalInformation from "./Forms/PersonalInformation.vue";
  import IncomeInformation from "./Forms/IncomeInformation.vue";
  import CharacterReferences from "./Forms/CharacterReferences.vue";
  import CoBorrowerInformation from "./Forms/CoBorrowerInformation.vue";
  import BankAccounts from "./Forms/BankAccounts.vue";
  import Requirements from "./Forms/Requirements.vue";
  import { useVuelidate } from '@vuelidate/core'
  import { required, email, helpers, numeric } from '@vuelidate/validators'
  import InputText from "./components/InputText.vue";

  const loan = ref({
    personal_information: {
      lastname: '',
      firstname: '',
      middlename: '',
      suffix: '',
      birth_date: '',
      place_of_birth: '',
      gender: '',
      civil_status: '',
      permanent_address: '',
      present_address: '',
      provincial_address: '',
      phone_number: '',
      email: '',
      facebook_account_name: '',
      nationality: '',
      TIN_NO: '',
      SSS_NO: '',
      PAGIBIG_NO: '',
      education: '',
      source_of_funds: '',
    },
    
    employer_information: {
      employer_business_employed: '',
      office_business_employed: '',
      nature_business_employment_employed: '',
      contact_information_employed: '',
      designation_position_employed:'',
      
    },
    character_references:[
    { 
      name: '',
      address: '',
      contact_number: '',
    },
    { 
      name: '',
      address: '',
      contact_number: '',
    },
    { 
      name: '',
      address: '',
      contact_number: '',
    },
    
    ],
    coborrowers:[
    {
      lastname: '',
      // firstname: '',
      // middlename: '',
      // suffix: '',
      // birth_date: '',
      // place_of_birth: '',
      // gender: '',
      // civil_status: '',
      // present_address: '',
      // address_ownership: '',
      // permanent_address: '',
      // provincial_address: '',
      // phone_number: '',
      // email: '',
      // facebook_account_name: '',
      // nationality: '',
      // education: '',
      // source_of_funds: '',
    }
    ],
    releasings:{
      bank: '',
      branch: '',
      date_opened: '',
      account_type: '',
      account_number: '',
    },
    requirements: {
      contract: null,
      seaman_book: null,
      e_reg: null,
      sirb: null,
      bill: null,
      valid_id_1: null,
      valid_id_2: null,
      marriage_contract:  null,
      send_it_thru: null,
    }
  })
  console.log(loan)
  const rules = {loan:{ 
    personal_information: {
      lastname: {required: helpers.withMessage('This field is required',required)},
      firstname: {required: helpers.withMessage('This field is required',required)},
      middlename: {required: helpers.withMessage('This field is required',required)},
      birth_date: {required: helpers.withMessage('This field is required',required)},
      place_of_birth: {required: helpers.withMessage('This field is required',required)},
      gender: {required: helpers.withMessage('This field is required',required)},
      civil_status: {required: helpers.withMessage('This field is required',required)},
      permanent_address: {required: helpers.withMessage('This field is required',required)},
      present_address: {required: helpers.withMessage('This field is required',required)},
      provincial_address: {required: helpers.withMessage('This field is required',required)},
      phone_number: {required: helpers.withMessage('This field is required',required),numeric: helpers.withMessage('This field should be numeric',numeric)},
      email: {required: helpers.withMessage('This field is required',required,email)},
      facebook_account_name: {required: helpers.withMessage('This field is required',required)},
      nationality: {required: helpers.withMessage('This field is required',required)},
      TIN_NO: {required: helpers.withMessage('This field is required',required)},
      SSS_NO: {required: helpers.withMessage('This field is required',required)},
      PAGIBIG_NO: {required: helpers.withMessage('This field is required',required)},
      education: {required: helpers.withMessage('This field is required',required)},
      source_of_funds: {required: helpers.withMessage('This field is required',required)},
    },
    employer_information: {
      employer_business_employed: {required: helpers.withMessage('This field is required',required)},
    },
     releasings: {
       bank: {required: helpers.withMessage('This field is required',required)},
       branch: {required: helpers.withMessage('This field is required',required)},
       date_opened: {required: helpers.withMessage('This field is required',required)},
       account_type: {required: helpers.withMessage('This field is required',required)},
       account_number: {required: helpers.withMessage('This field is required',required)},
     },
  }
}
const step2Rules={
  loan:{ 
    coborrowers:{
      $each:helpers.forEach({
      lastname: {required: helpers.withMessage('This field is required',required)},
      // firstname: {required: helpers.withMessage('This field is required',required)},
      // middlename: {required: helpers.withMessage('This field is required',required)},
      // suffix: {required: helpers.withMessage('This field is required',required)},
      // birth_date: {required: helpers.withMessage('This field is required',required)},
      // place_of_birth: {required: helpers.withMessage('This field is required',required)},
      // gender: {required: helpers.withMessage('This field is required',required)},
      // civil_status: {required: helpers.withMessage('This field is required',required)},
      // present_address: {required: helpers.withMessage('This field is required',required)},
      // address_ownership: {required: helpers.withMessage('This field is required',required)},
      // permanent_address: {required: helpers.withMessage('This field is required',required)},
      // provincial_address: {required: helpers.withMessage('This field is required',required)},
      // phone_number: {required: helpers.withMessage('This field is required',required)},
      // email: {required: helpers.withMessage('This field is required',required)},
      // facebook_account_name: {required: helpers.withMessage('This field is required',required)},
      // nationality: {required: helpers.withMessage('This field is required',required)},
      // education: {required: helpers.withMessage('This field is required',required)},
      // source_of_funds: {required: helpers.withMessage('This field is required',required)},
  })
  },
    
  }
}


    const validator = useVuelidate(rules, {loan})
    const step2Validator = useVuelidate(step2Rules,{loan})
    console.log('validator',validator);
  
    const currentStep = ref(0);
   

    

const steps = ["Personal Information","Income Information","Bank Account", "Co Borrower"];

const nextStep = () => {
  console.log('LABAS',!validator.value.$error)
  validator.value.$touch()
  if (validator.value.$error && currentStep.value == 0 ) {
    return false;
  }
  if (currentStep.value == 1 ){
    validator.value.$touch()
  if (validator.value.$error) {
    console.log('labas',validator.value.$error)
  }

  } 
  if (currentStep.value == 2 ){
    validator.value.$touch();

  } if ( validator.value.$error ){
    console.log('labas',validator.value.$error);
   
  }else {
    currentStep.value++;
  }

  
  
};



const prevStep = () => {
  if (currentStep.value > 0) {
    currentStep.value--;
  }
};

  </script>


  <style scoped>

  </style>