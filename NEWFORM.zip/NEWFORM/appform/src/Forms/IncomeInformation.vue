<template>
    <div>
        <div class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 dark:text-gray-200">
                INCOME INFORMATION
            </h2>
        </div>
            <div class="sm:col-span-3">
                <label for="af-account-name_of_employer_business" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
                    NAME OF EMPLOYER / BUSINESS
                </label>
            </div>
            <!-- <InputText 
                class="my-3"
                v-model:model="incomeInformation.employer_business_employed"
                label="Employer*"
                :hasError="validator.loan.employer_information.employer_business_employed.$error"
                :errors="validator.loan.employer_information.employer_business_employed.$errors"
                inputType="text"    
            /> -->
            <div class="sm:col-span-9">
                <div class="sm:flex">
                    <input v-model="incomeInformation.employer_business_employed" 
                        :hasError="validator.loan.employer_information.employer_business_employed.$error"
                        :errors="validator.loan.employer_information.employer_business_employed.$errors"
                        
                        type="text"
                        class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm -mt-px -ms-px 
                        first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none 
                        sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 
                        disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400
                         dark:focus:ring-gray-600"
                        placeholder="EMPLOYED">
                    
                </div>
            </div>
            <div >
                        <p v-for="(error, index) in validator.loan.employer_information.employer_business_employed.$errors" :key="index" 
                        
                        class="text-sm text-red-600 mt-2" id="hs-validation-name-error-helper">
                        {{ error.$message }}
                        </p>
                    </div>
<!-- 
            <div class="sm:col-span-3">
                <label for="af-account-name_of_office_business" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
                    OFFICE / BUSINESS ADDRESS
                </label>
            </div>
            <div class="sm:col-span-9">
                <div class="sm:flex">
                    <input v-model="incomeInformation.office_business_employed" type="text"
                        class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600"
                        placeholder="EMPLOYED">
                    
                </div>
            </div>
            <div class="sm:col-span-3">
                <label for="af-account-name_of_nature_business" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
                    NATURE OF BUSINESS / EMPLOYMENT
                </label>
            </div>
            <div class="sm:col-span-9">
                <div class="sm:flex">
                    <input v-model="incomeInformation.nature_business_employment_employed" type="text"
                        class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600"
                        placeholder="EMPLOYED">
                    
                </div>
            </div>
            <div class="sm:col-span-3">
                <label for="af-account-name_of_contact_information" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
                    CONTACT INFORMATION
                </label>
            </div>
            <div class="sm:col-span-9">
                <div class="sm:flex">
                    <input v-model="incomeInformation.contact_information_employed" type="text"
                        class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600"
                        placeholder="EMPLOYED">
                    
                </div>
            </div>
            <div class="sm:col-span-3">
                <label for="af-account-name_of_designation_position" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
                    DESIGNATION / POSITION
                </label>
            </div>
            <div class="sm:col-span-9">
                <div  class="sm:flex">
                    <input v-model="incomeInformation.designation_position_employed" type="text"
                        class="py-2 px-3 pe-11 block w-full border-gray-200 shadow-sm -mt-px -ms-px first:rounded-t-lg last:rounded-b-lg sm:first:rounded-s-lg sm:mt-0 sm:first:ms-0 sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-lg text-sm relative focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:ring-gray-600"
                        placeholder="EMPLOYED">
                    
                </div>
            </div> -->
    </div>
</template>

<script setup>
import InputText from '@/components/InputText.vue';
    const incomeInformation = defineModel ('incomeInformation',{default:{}})
    const validator = defineModel('validator')
    console.log('validator from PI',validator)
</script> 

<style scoped>

</style>