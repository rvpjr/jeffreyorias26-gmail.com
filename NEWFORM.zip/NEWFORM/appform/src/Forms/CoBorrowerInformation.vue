<template>
    <div >
        <InputText 
            class="my-3"
            v-model:model="coborrowerInformation.lastname"
            label="Last Name *"
            inputType="text"   
            :hasErrors="validator.loan.coborrowers.$each.$response.$data[0].lastname.$errors "
            :errors="validator.error ? validator.$errors[0].$response.$errors[0].lastname[0]: [] "
             
        />

    </div>
</template>

<script setup>
import InputText from '@/components/InputText.vue';
    const coborrowerInformation = defineModel ('coborrowerInformation',{default:{}})
    const validator = defineModel('validator')
    console.log('validator from CB', validator)
</script>

<style scoped>

</style>