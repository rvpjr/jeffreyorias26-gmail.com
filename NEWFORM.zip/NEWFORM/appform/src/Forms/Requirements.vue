<template>
    <div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            CONTRACT
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="contract" @change="(event) => handleFileUpload(event,'contract')" 
          type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm 
          rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none
           dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            SEAMAN BOOK
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="seaman_book" @change="(event) => handleFileUpload(event,'seaman_book')" 
          type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm 
          rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none
           dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            E-REGISTRATION
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="e_reg" @change="(event) => handleFileUpload(event,'e_reg')"
           type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm 
           rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none
            dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            SEAFARER'S IDENTIFICATION AND RECORD BOOK
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="sirb" @change="(event) => handleFileUpload(event,'sirb')" 
          type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm 
          rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none
           dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            BILL
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="bill" @change="(event) => handleFileUpload(event,'bill')" 
          type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm
           rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none
            dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            VALID ID
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="valid_id_1" @change="(event) => handleFileUpload(event,'valid_id_1')"
           type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm 
           rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none
            dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            VALID ID
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="valid_id_2" @change="(event) => handleFileUpload(event,'valid_id_2')" 
          type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            MARRIAGE CONTRACT
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="marriage_contract" @change="(event) => handleFileUpload(event,'marriage_contract')" type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>
        <div class="sm:col-span-9">
          <div class="sm:col-span-9">
            <h2 for="file-input" class="inline-block text-sm text-gray-800 mt-2.5 dark:text-gray-200">
            EMAIL ADDRESS
          </h2>
          </div>
        </div>
        <div class="sm:col-span-9">
          <label for="small-file-input" class="sr-only">Choose file</label>
          <input ref="send_it_thru" @change="(event) => handleFileUpload(event,'send_it_thru')" type="file" name="small-file-input" id="small-file-input" class="block w-full border border-gray-200 shadow-sm rounded-lg text-sm focus:z-10 focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-gray-400 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600
            file:bg-gray-50 file:border-0
            file:me-4
            file:py-2 file:px-4
            dark:file:bg-gray-700 dark:file:text-gray-400">
        </div>

        
    </div>
</template>

<script setup>
import { ref } from "vue"

    const Requirements = defineModel('Requirements',{default:{}});
    const contract = ref(null);
    const seaman_book = ref(null);
    const e_reg = ref(null);
    const sirb = ref(null);
    const bill = ref(null);
    const valid_id_1 = ref(null);
    const valid_id_2 = ref(null);
    const marriage_contract = ref(null);
    const send_it_thru = ref(null);

    const handleFileUpload = (event,fieldName) => {
      Requirements.value[fieldName] = event.target.files[0];
      
    }
    console.log(Requirements)

</script>

<style scoped>

</style>