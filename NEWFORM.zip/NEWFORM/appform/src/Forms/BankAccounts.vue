<template>
  <div>
     <div class="my-5">
            <h2>BANK ACCOUNTS</h2>
          
            <InputText 
                    class="my-3"
                    v-model:model="bankAccounts.bank"
                    label="bank *"
                    :hasError="validator.loan.releasings.bank.$error"
                    :errors="validator.loan.releasings.bank.$errors"
                    inputType="text" 
                    />
                    <InputText 
                    class="my-3"
                    v-model:model="bankAccounts.branch"
                    label="branch *"
                    :hasError="validator.loan.releasings.branch.$error"
                    :errors="validator.loan.releasings.branch.$errors"
                    inputType="text" 
                    />
                    <InputText 
                    class="my-3"
                    v-model:model="bankAccounts.date_opened"
                    label="date opened *"
                    :hasError="validator.loan.releasings.date_opened.$error"
                    :errors="validator.loan.releasings.date_opened.$errors"
                    inputType="text" 
                    />
                    <InputText 
                    class="my-3"
                    v-model:model="bankAccounts.account_type"
                    label="account type*"
                    :hasError="validator.loan.releasings.account_type.$error"
                    :errors="validator.loan.releasings.account_type.$errors"
                    inputType="text" 
                    />
                    <InputText 
                    class="my-3"
                    v-model:model="bankAccounts.account_number"
                    label="account number*"
                    :hasError="validator.loan.releasings.account_number.$error"
                    :errors="validator.loan.releasings.account_number.$errors"
                    inputType="text" 
                    />
    </div>
  </div>
</template> 

<script setup>
import InputText from '@/components/InputText.vue';
const bankAccounts = defineModel('bankAccounts',{default:{}})
const validator = defineModel('validator')
console.log('validator from BA',validator)

</script>

<style scoped>

</style>